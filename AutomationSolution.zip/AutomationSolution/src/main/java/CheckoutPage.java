import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class CheckoutPage extends BasePage {

    public CheckoutPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(xpath = "//a[text()='Food']")
    private WebElement foodMenu;

    @FindBy(css = " .product-info button")
    private WebElement addToCart;

    @FindBy(id = "city")
    private WebElement cityCart;

    @FindBy(id = "postcode")
    private WebElement postCode;

    @FindBy(id = "region_id")
    public WebElement cartRegion;

    public void getFoodMenu() {
        foodMenu.click();

    }

    public void clickAddtoCart(){
        foodMenu.click();
    }

    public void setCityCart(){
        cityCart.sendKeys("Alabama");
    }

    public void setPostCode(){
        postCode.sendKeys("12345");
    }

    public void setCartRegion() {
        cartRegion.sendKeys("Alabama");
    }

    public void selectOption (WebElement element, String option) {
        Select optionSelect = new Select (element);
        optionSelect.selectByVisibleText(option);
    }
}
